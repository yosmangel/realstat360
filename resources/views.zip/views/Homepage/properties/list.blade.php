<div class="container">
    <div class="row">
        <div class="col-xs-12">
            @include('properties.sections.cards')
        </div>
    </div>
</div>
