<div class="container">
	<div class="row center">
		<div class="col-md-12 testimonial testimonial-style-4">
			<h2 class="mb-sm word-rotator-title">
				¿Cómo lo Hacemos?
			</h2>
			<hr class="tall">
			<h3 class="heading-primary lead tall">Facilitamos a los Propietarios acceder a toda la Demanda filtrada según sus Preferencias.</h3>
			<div class="col-xs-12 col-md-6 col-md-offset-3">
				<blockquote class="text-lg text-spacing">
					Nuestro Auténtico Trabajo es Ponerte en Contacto directo con Clientes.
				</blockquote>
			</div>
		</div>
	</div>
</div>