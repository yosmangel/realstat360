<section class="call-to-action call-to-action-info with-button-arrow call-to-action-in-footer call-to-action-in-footer-margin-top">
    <div class="container">
        <div class="row top-min">
            <div class="col-md-8">
                <div class="call-to-action-content">
                    <p class="text-call-to-action-info">
                        Descubre nuestros servicios exclusivos <br>para 
                        <strong><em>Vender o Alquilar</em></strong>
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="call-to-action-btn">
                    <a href="{{ url('/tipo-registro') }}" class="btn btn-lg btn-rs360-deep-blue">¡Regístrate!</a><span class="arrow hlb hidden-xs hidden-sm hidden-md" data-appear-animation="rotateInUpLeft" style="top: -12px;"></span>
                </div>
            </div>
        </div>
    </div>
</section>