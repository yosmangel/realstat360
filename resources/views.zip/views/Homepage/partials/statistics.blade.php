<section id="statistics" class="section section-primary">
    <div class="container">
        <div class="row">
            <div class="counters counters-text-light">
                <div class="col-md-3 col-sm-6">
                    <div class="counter">
                        <strong data-to="150" data-append="+">0</strong>
                        <label>PROPIETARIOS</label>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="counter">
                        <strong data-to="200" data-append="+">0</strong>
                        <label>CLIENTES</label>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="counter">
                        <strong data-to="176">0</strong>
                        <label>INMUEBLES</label>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="counter">
                        <strong data-to="118">0</strong>
                        <label>INTERCAMBIOS REALIZADOS</label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>