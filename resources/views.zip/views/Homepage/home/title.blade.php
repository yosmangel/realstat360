<section class="section section-default" id="title-propietaries">
	<div class="container-fluid sample-item-container">
		<div class="row">
			<div class="col-md-12 center pb-xl">
				<h2 class="mt-xlg pt-md mb-none"><strong>Bienvenido</strong> {{ Auth::user()->name }}</h2>
				<p class="lead">Todas las facilidades para ...<span class="alternative-font font-size-xl">&nbsp;administrar y comercializar tus Inmuebles!</span></p>
			</div>
		</div>
	</div>
</section>