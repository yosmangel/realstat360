<div class="col-de-12">
	<!-- En el div siguiente se inserta el inmueble de la demanda en caso de que los requerimientos
	de la demanda coincidad con las caracteristicas del inmueble -->
	<div id="response"></div>
</div>