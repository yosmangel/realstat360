<section class="panel panel-featured panel-featured-primary">
				<header class="panel-heading">
					<h2 class="panel-title">Facturación</h2>
				</header>
				<div class="panel-body">
					<div class="col-xs-12 col-sm-6">
						<div class="alert alert-info fade in nomargin">
							<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
							<h4>Tus Facturas</h4>
							<p>Recuerda que tienes todas tus facturas disponibles en:</p>
							<p>
								<a type="button" class="btn btn-info mt-xs mb-xs" href="https://as1.ondemand.esker.com/ondemand/webaccess/CustomerLogon.aspx?uid=7D706C454B584A782471664A5856484927&user=&language=es&skin=Generic">Acceso a Mis Facturas</a>
							</p>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6">
						<div class="alert alert-info fade in nomargin">
							<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
							<h4>Contáctanos</h4>
							<p>Puedes contactar con nosotros a traves del correo:</p>
							<p>
								<a href="mailto:administracion@scmspain.com">administracion@scmspain.com</a>
							</p>
						</div>
					</div>
				</div>
			</section>